// Bounded, local-only raw DEFLATE decoder for older Safari and other browsers.
function pwaInflate(bytes,limit){if(!Number.isSafeInteger(limit)||limit<0||limit>250*1024*1024)throw Error('ZIP 解压大小异常');const dec=new pako.Inflate({raw:true,chunkSize:32768}),chunks=[];let total=0;dec.onData=function(chunk){total+=chunk.length;if(total>limit)throw Error('ZIP 解压大小异常');chunks.push(chunk)};dec.push(bytes,true);if(dec.err||!dec.ended||total!==limit)throw Error('ZIP 解压失败或长度不符');const result=new Uint8Array(total);let at=0;for(const chunk of chunks){result.set(chunk,at);at+=chunk.length}return result}
// Keep migration rollback metadata outside the small localStorage quota.
let pwaMetaDB;
function pwaSnapshot(write,value){if(!pwaMetaDB)pwaMetaDB=new Promise((ok,no)=>{const r=indexedDB.open('College100-pwa-protection',1);r.onupgradeneeded=()=>r.result.createObjectStore('meta');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error);r.onblocked=()=>no(Error('备份数据库被其他窗口占用'))});return pwaMetaDB.then(db=>new Promise((ok,no)=>{const t=db.transaction('meta',write?'readwrite':'readonly'),s=t.objectStore('meta'),r=write?s.put(value,'snapshot'):s.get('snapshot');let result;r.onsuccess=()=>result=r.result;t.oncomplete=()=>ok(result);t.onabort=t.onerror=()=>no(t.error||Error('快照保存失败'))}))}
(function(){
 const states={};const put=(id,t)=>{states[id]=t;const n=document.getElementById(id);if(n&&n.textContent!==t)n.textContent=t};
 const status=t=>{window.__pwaStatus=t;put('pwa-cache-status',t)};
 const readDate=()=>{try{return localStorage.getItem('college100-pwa-last-export')}catch(e){return null}};
 function backupStatus(){const d=readDate();let text='尚无本机备份生成记录。建议定期导出到文件 App。';if(d){const age=(Date.now()-Date.parse(d))/86400000;text='最近生成备份：'+new Date(d).toLocaleDateString()+'。'+(age>=7?'已超过一周，建议再次备份。':'请确认文件已保存。')}put('pwa-backup-status',text)}
 window.pwaBackupPrepared=()=>{try{localStorage.setItem('college100-pwa-last-export',new Date().toISOString())}catch(e){}backupStatus()};
 async function storage(ask){try{const s=navigator.storage;if(!s)throw Error();const persistent=ask?await s.persist?.():await s.persisted?.();const e=await s.estimate?.();const usage=e&&Number.isFinite(e.usage)?' · 已用约 '+Math.round(e.usage/1048576)+' MB':'';put('pwa-storage-status',(persistent?'已获准持久化存储，仍须备份。':'未获持久化保证，请定期备份。')+usage)}catch(e){put('pwa-storage-status','无法确认存储状态，请定期备份。')}}
 window.pwaRequestPersistence=()=>storage(true);
 let reg=null,busy=false;
 async function request(type){if(!reg||!navigator.serviceWorker.controller)throw Error('离线应用尚未接管此页面，请联网重新打开');return new Promise((ok,no)=>{const c=new MessageChannel();let t=setTimeout(()=>{c.port1.close();no(Error('检查超时，请重试'))},type==='C100_REPAIR'?180000:30000);c.port1.onmessage=e=>{clearTimeout(t);c.port1.close();ok(e.data)};navigator.serviceWorker.controller.postMessage({type},[c.port2])})}
 async function check(repair){if(busy)return;busy=true;status(repair?'正在补齐离线资源…':'正在逐项检查离线资源…');try{const r=await request(repair?'C100_REPAIR':'C100_VERIFY');if(r.error)throw Error(r.error);status(r.missing===0?'离线资源已核验完整（'+r.total+'/'+r.total+'）。请进行飞行模式试用。':'离线资源缺少 '+r.missing+' 项，请联网补齐。')}catch(e){status('离线未确认：'+e.message)}finally{busy=false}}
 window.pwaCheckOffline=()=>check(false);window.pwaRepairOffline=()=>check(true);
 new MutationObserver(()=>{for(const [id,t] of Object.entries(states)){const n=document.getElementById(id);if(n&&n.textContent!==t)n.textContent=t}}).observe(document.body,{childList:true,subtree:true});
 backupStatus();storage(false);
 if(!('serviceWorker' in navigator)||!window.isSecureContext){status('需要通过 HTTPS 网站打开，才能安装和离线使用。');return}
 status('首次加载正在缓存离线资源，请保持网页打开。');
 navigator.serviceWorker.addEventListener('message',e=>{if(e.data?.type==='C100_PROGRESS')status(`正在缓存离线资源 ${e.data.done}/${e.data.total}…`)});
 navigator.serviceWorker.addEventListener('controllerchange',()=>{if(reg)check(false)});
 navigator.serviceWorker.register('./sw.js').then(async r=>{reg=r;const w=r.installing||r.waiting;if(w)w.addEventListener('statechange',()=>{if(w.state==='redundant')status('离线缓存失败，请联网重新打开网页。')});await navigator.serviceWorker.ready;await check(false)}).catch(()=>status('离线缓存失败，请联网重新打开网页。'));
 window.addEventListener('online',()=>check(false));
})();
